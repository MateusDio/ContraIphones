package br.ulbra.exemplo


import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.graphics.Color
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets


        }

    }


//    fun clique(view: View) {
//        println("foi clicado!!!")
//    }

    var rolagem = 0

    fun sortear(view: View) {
        val textoResultado = findViewById<TextView>(R.id.ResultadoTxt)
        val numero = Random().nextInt(7)
        rolagem++

        if (numero % 2 == 0) {
            textoResultado.setTextColor(Color.BLUE)
            println("Número par sorteado: $numero")
        } else {
            textoResultado.setTextColor(Color.RED)
            println("Número impar sorteado: $numero")
        }

        textoResultado.text = "Rolagem: $rolagem / Resultado gerado: $numero"
    }


    fun zerar(view: View) {
        val textoResultado = findViewById<TextView>(R.id.ResultadoTxt)
        textoResultado.setText("Resultado")
    }

    var clique = 0;
    fun contarClique(view: View){
        clique++
        println("Contagem de cliques: $clique " )
    }



}




